//
//  ISChaoEnergyProgressLayer.h
//  ISRedBlueView
//
//  Created by run on 2018/9/7.
//  Copyright © 2018年 IS. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface ISChaoEnergyProgressLayer : CALayer

@property(nonatomic) CGFloat layerHeight;
@property(nonatomic) CGFloat progress;

@end
